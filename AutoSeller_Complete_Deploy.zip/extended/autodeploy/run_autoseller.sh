#!/bin/bash
python3 bot.py &
echo 'Bot AutoSeller avviato...'