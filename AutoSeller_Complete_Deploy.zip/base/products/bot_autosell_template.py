# Bot template auto-vendita
