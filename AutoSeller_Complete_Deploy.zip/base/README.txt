Bot Telegram AutoSeller - Istruzioni:
1. Esegui bot.py
2. Configura token
3. Inserisci file in /products
4. Invia via Telegram
