# Placeholder for Telegram bot script
print('Bot avviato')